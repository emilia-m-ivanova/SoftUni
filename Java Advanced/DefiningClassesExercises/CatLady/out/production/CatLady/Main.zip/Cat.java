public class Cat {
    String name;

    public String getName() {
        return name;
    }
}
