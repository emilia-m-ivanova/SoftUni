public class Cymric extends Cat{

    private double furLength;

    public Cymric (String name, double furLength){
        this.name = name;
        this.furLength = furLength;
    }

    @Override
    public String toString() {
        return "Cymric " +
                this.name +
                " " +
                String.format("%.2f",this.furLength);
    }
}
