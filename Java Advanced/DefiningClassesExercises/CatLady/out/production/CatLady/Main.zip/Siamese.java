public class Siamese extends Cat{

    private double earSize;

    public Siamese (String name, double earSize){
        this.name = name;
        this.earSize = earSize;
    }

    @Override
    public String toString() {
        return "Siamese " +
                this.name +
                " " +
                String.format("%.2f",this.earSize);
    }
}
