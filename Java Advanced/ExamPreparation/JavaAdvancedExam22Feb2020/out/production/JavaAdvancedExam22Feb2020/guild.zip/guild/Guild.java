package guild;

import javax.print.DocFlavor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Guild {

    private List<Player> roster;
    private String name;
    private int capacity;

    public Guild(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster = new ArrayList<>();
    }

    public void addPlayer(Player player){
        if(this.capacity>this.roster.size()){
            this.roster.add(player);
        }
    }

    public boolean removePlayer (String name){
        for (Player player : this.roster) {
            if(player.getName().equals(name)){
                this.roster.remove(player);
                return true;
            }
        }
        return false;
    }

    public void promotePlayer (String name){
        Player player = this.roster.stream()
                .filter(p->p.getName().equals(name))
                .findFirst()
                .orElse(null);
        assert player != null;
        player.setClazz("Member");
    }

    public void demotePlayer (String name){
        Player player = this.roster.stream()
                .filter(p->p.getName().equals(name))
                .findFirst()
                .orElse(null);
        assert player != null;
        player.setClazz("Trial");
    }

    public Player[] kickPlayersByClass(String clazz){

        List<Player> kickedPlayers = this.roster.stream()
                .filter(p->p.getClazz().equals(clazz))
                .collect(Collectors.toList());
        this.roster = this.roster.stream()
                .filter(p->!p.getClazz().equals(clazz))
                .collect(Collectors.toList());
        Player[] arr = new Player[kickedPlayers.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = kickedPlayers.get(i);
        }
        return arr;
    }

    public int count(){
        return this.roster.size();
    }

    public String report() {
     StringBuilder sb = new StringBuilder();
     sb.append("Players in the guild: ").append(this.name).append(":").append(System.lineSeparator());
        for (Player player : this.roster) {
            sb.append(player.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }

}
