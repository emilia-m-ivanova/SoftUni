package CustomList;
import java.util.NoSuchElementException;

public class CustomList<T extends Comparable<T>> {
    private static final int INITIAL_CAPACITY = 4;
    private Object[] elements;
    private int size;

    public CustomList() {
        this.elements = new Object[INITIAL_CAPACITY];
        this.size = 0;
    }

    public void add(T element) {
        if (this.size == this.elements.length) {
            this.elements = grow(this.elements);
        }
        this.elements[size++] = element;
    }

    private Object[] grow(Object[] elements) {
        Object[] arrDoubled = new Object[elements.length * 2];
        System.arraycopy(elements, 0, arrDoubled, 0, elements.length);
        return arrDoubled;
    }

    public T remove(int index) {
        T element = (T) this.elements[index];
        if (elements.length - 1 - index >= 0)
            System.arraycopy(elements, index + 1, elements, index, elements.length - 1 - index);
        this.size--;
        if (this.size == elements.length / 3) {
            this.elements = shrink(this.elements);
        }
        return element;
    }

    private Object[] shrink(Object[] elements) {
        Object[] arrShrunk = new Object[elements.length / 3];
        System.arraycopy(elements, 0, arrShrunk, 0, arrShrunk.length);
        return arrShrunk;
    }

    private boolean isEmpty() {
        return this.size == 0;
    }

    public boolean contains(T element) {
        if (isEmpty()) {
            return false;
        }
        for (Object obj : this.elements) {
            if (obj != null && obj.equals(element)) {
                return true;
            }
        }
        return false;
    }

    public void swap(int indexOne, int indexTwo) throws IndexOutOfBoundsException {
        if (indexIsInBounds(indexOne) && indexIsInBounds(indexTwo)) {
            T temp = (T) this.elements[indexOne];
            this.elements[indexOne] = this.elements[indexTwo];
            this.elements[indexTwo] = temp;
            return;
        }
        throw new IndexOutOfBoundsException("Index is out of bounds for size " + this.size);
    }

    private boolean indexIsInBounds(int index) {
        return 0 <= index && index < this.size;
    }

    public int countGreaterThan(T element) {
        int count = 0;
        for (Object o : this.elements) {
            if(o!=null){
                T currentElement = (T) o;
                if(currentElement.compareTo(element)>0){
                    count++;
                }
            }
        }

        return count;
    }

    public T getMax() throws NoSuchElementException {
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        T maxElement = (T) this.elements[0];
        for (Object o : this.elements) {
            if(o!=null){
                T currentElement = (T) o;
                if(currentElement.compareTo(maxElement)>0){
                    maxElement = currentElement;
                }
            }
        }
        return maxElement;
    }

    public T getMin() throws NoSuchElementException {
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        T minElement = (T) this.elements[0];
        for (Object o : this.elements) {
            if(o!=null){
                T currentElement = (T) o;
                if(currentElement.compareTo(minElement)<0){
                    minElement = currentElement;
                }
            }
        }
        return minElement;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(this.elements[i] + System.lineSeparator());
        }
        return String.valueOf(sb);
    }
}
