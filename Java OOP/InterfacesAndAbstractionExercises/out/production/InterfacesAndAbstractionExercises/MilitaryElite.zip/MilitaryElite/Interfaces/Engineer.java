package MilitaryElite.Interfaces;

import MilitaryElite.Repair;

import java.util.Set;

public interface Engineer {
    Set<Repair> repairs();
}
