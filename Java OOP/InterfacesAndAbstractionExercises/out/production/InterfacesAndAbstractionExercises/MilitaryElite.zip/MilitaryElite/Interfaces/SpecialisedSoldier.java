package MilitaryElite.Interfaces;

import MilitaryElite.Corps;

public interface SpecialisedSoldier {
    Corps getCorps();
}
