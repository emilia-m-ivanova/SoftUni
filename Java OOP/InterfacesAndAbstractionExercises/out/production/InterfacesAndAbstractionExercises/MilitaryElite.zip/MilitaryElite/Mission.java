package MilitaryElite;

public class Mission {
    String codeName;
    State state;

    public Mission(String codeName, State state) {
        this.codeName = codeName;
        this.state = state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void completeMission(){
        this.state = State.Finished;
    }

    @Override
    public String toString() {
        return String.format("Code Name: %s State: ",this.codeName,
                this.state.toString().charAt(0) )+ this.state.toString();
    }
}
