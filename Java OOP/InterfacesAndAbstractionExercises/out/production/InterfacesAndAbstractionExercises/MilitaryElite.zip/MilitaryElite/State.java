package MilitaryElite;

public enum State {
    InProgress,
    Finished,
}
