package MilitaryElite.Interfaces;

import MilitaryElite.Mission;

import java.util.Collection;
import java.util.Set;

public interface Commando {
    Collection<Mission> getMissions();
}
