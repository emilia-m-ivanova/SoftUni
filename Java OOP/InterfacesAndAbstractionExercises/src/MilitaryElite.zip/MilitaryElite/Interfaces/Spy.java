package MilitaryElite.Interfaces;

public interface Spy {
    String getCodeNumber();
}
